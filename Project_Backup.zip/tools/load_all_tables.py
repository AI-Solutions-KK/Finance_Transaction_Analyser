# Path: tools/load_all_tables.py
# FINAL enrichment logic

import pandas as pd
from sqlalchemy import text
from database.db_engine import SessionLocal

BANK_CODES = ["BOI", "HDFC", "SBI", "AXIS", "ICICI", "YES", "KOTAK", "MAHB"]

CATEGORY_RULES = {
    "EMI": ["emi"],
    "CREDIT_CARD": ["credit card"],
    "FOOD": ["hotel", "food", "restaurant"],
    "SHOPPING": ["amazon", "flipkart", "mall", "shop"],
    "UTILITY": ["mobile", "recharge", "electric", "bill", "myjio"],
    "MEDICAL": ["medical", "hospital", "pharma"],
    "SERVICE": ["servic", "mandat", "renewal"],
    "INVESTMENT": ["gold", "lic", "policy"],
    "PERSONAL": ["papa", "mama"],
    "TRANSFER": ["self"],
    "REFUND": ["refund"]
}

def extract_ref_id(remarks):
    parts = remarks.split("/")
    return parts[1] if len(parts) > 1 else None

def extract_bank_code(remarks):
    for code in BANK_CODES:
        if f"/{code}/" in remarks:
            return code
    return "UNKNOWN"

def detect_category(remarks):
    r = remarks.lower()
    for cat, keys in CATEGORY_RULES.items():
        if any(k in r for k in keys):
            return cat
    return "OTHER"

def detect_method(code):
    if code == "UPI":
        return "UPI"
    if code == "CWDR":
        return "ATM"
    if "SBINT" in code.upper():
        return "INTEREST"
    return "BANK"

def detect_nature(debit, credit):
    if credit > 0 and debit == 0:
        return "INCOME"
    if debit > 0 and credit == 0:
        return "EXPENSE"
    return "TRANSFER"


def load_all_tables(csv_path, session_id):
    db = SessionLocal()
    df = pd.read_csv(csv_path)

    df["transaction_date"] = pd.to_datetime(df["transaction_date"]).dt.date
    df["debit"] = df["debit"].fillna(0)
    df["credit"] = df["credit"].fillna(0)
    df["amount"] = df["debit"] + df["credit"]

    for _, row in df.iterrows():
        remarks = str(row["remarks"])
        txn_code = remarks.split("/")[0]

        db.execute(
            text("""
                INSERT INTO fact_transactions (
                    session_id, txn_date,
                    transaction_ref_id, transaction_code,
                    transaction_method, transaction_category,
                    transaction_nature,
                    counterparty_name, counterparty_bank_code,
                    debit, credit, amount, balance, remarks
                ) VALUES (
                    :sid, :dt,
                    :ref, :code,
                    :method, :category,
                    :nature,
                    :cp_name, :bank,
                    :debit, :credit, :amount, :bal, :remarks
                )
            """),
            {
                "sid": session_id,
                "dt": row["transaction_date"],
                "ref": extract_ref_id(remarks),
                "code": txn_code,
                "method": detect_method(txn_code),
                "category": detect_category(remarks),
                "nature": detect_nature(row["debit"], row["credit"]),
                "cp_name": remarks.split("/")[3] if "/" in remarks else "UNKNOWN",
                "bank": extract_bank_code(remarks),
                "debit": row["debit"],
                "credit": row["credit"],
                "amount": row["amount"],
                "bal": row["balance"],
                "remarks": remarks
            }
        )

    db.commit()
    db.close()
