import pandas as pd
import numpy as np
import pdfplumber
import re
import os
import json
import uuid
from datetime import datetime
from sqlalchemy import inspect, Table, Column, Integer, String, Float, DateTime, MetaData, text
from sqlalchemy.dialects.sqlite import DATE, TIMESTAMP
from sqlalchemy.exc import SQLAlchemyError
from database.db_engine import engine, Base, SessionLocal


# --- Audit Model ---
class UploadAudit(Base):
    __tablename__ = "uploads_audit"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True)
    filename = Column(String)
    csv_path = Column(String)
    rows_inserted = Column(Integer)
    created_table = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)


# Ensure audit table exists
Base.metadata.create_all(bind=engine)


class DataTransformer:
    """
    Handles Parsing, Cleaning, and Normalizing Data.
    Target: Dashboard-ready format.
    """

    CANONICAL_MAP = {
        'date': 'transaction_date',
        'txn date': 'transaction_date',
        'value date': 'value_date',
        'particulars': 'description',
        'narrative': 'description',
        'desc': 'description',
        'withdrawal': 'debit',
        'dr': 'debit',
        'deposit': 'credit',
        'cr': 'credit',
        'bal': 'balance',
        'ref': 'reference_no',
        'chq': 'cheque_no'
    }

    def __init__(self):
        pass

    def parse_file(self, file_path: str, file_ext: str) -> pd.DataFrame:
        """Dispatcher for file parsing"""
        if file_ext == '.csv':
            df = pd.read_csv(file_path)
        elif file_ext in ['.xls', '.xlsx']:
            df = pd.read_excel(file_path)
        elif file_ext == '.pdf':
            df = self._parse_pdf(file_path)
        else:
            raise ValueError(f"Unsupported format: {file_ext}")

        return self._clean_dataframe(df)

    def _parse_pdf(self, path: str) -> pd.DataFrame:
        """
        Heuristic PDF Parser using pdfplumber.
        Attempts to find table structures.
        """
        all_rows = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                # 1. Try extract_table (works if lines are drawn)
                table = page.extract_table()
                if table:
                    all_rows.extend(table)
                else:
                    # 2. Fallback: Extract text and try basic splitting (very naive)
                    text_content = page.extract_text()
                    if text_content:
                        lines = text_content.split('\n')
                        for line in lines:
                            # Split by multiple spaces
                            parts = re.split(r'\s{2,}', line.strip())
                            if len(parts) > 2:  # Ignore noise
                                all_rows.append(parts)

        if not all_rows:
            return pd.DataFrame()

        # Promote first row to header if it looks like one
        headers = all_rows[0]
        data = all_rows[1:]
        df = pd.DataFrame(data, columns=headers)
        return df

    def _clean_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Applies cleaning rules to make data BI-ready.
        """
        # 1. Normalize Headers
        df.columns = [str(c).strip().lower().replace('.', '') for c in df.columns]
        df.rename(columns=lambda x: self.CANONICAL_MAP.get(x, x), inplace=True)

        # 2. Remove purely empty rows/cols
        df.dropna(how='all', inplace=True)

        # 3. Standardize Dates
        if 'transaction_date' in df.columns:
            df['transaction_date'] = pd.to_datetime(df['transaction_date'], errors='coerce')

        # 4. Standardize Numbers (Remove commas, currency symbols)
        num_cols = ['debit', 'credit', 'balance', 'amount']
        for col in num_cols:
            if col in df.columns:
                df[col] = (
                    df[col].astype(str)
                    .str.replace(',', '', regex=False)
                    .str.replace('$', '', regex=False)
                    .str.replace('Cr', '', regex=False)  # Common banking notation
                    .str.replace('Dr', '', regex=False)
                )
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0)

        # 5. Calculation: Fill Nulls & Ensure logic
        # If Debit/Credit exist, create Net Amount
        if 'debit' in df.columns and 'credit' in df.columns:
            df['net_amount'] = df['credit'] - df['debit']
            df['transaction_type'] = df.apply(
                lambda x: 'Credit' if x['credit'] > 0 else ('Debit' if x['debit'] > 0 else 'Neutral'), axis=1
            )

        # 6. Drop Rows without critical data (Date)
        if 'transaction_date' in df.columns:
            df = df.dropna(subset=['transaction_date'])

        return df

    def generate_schema_manifest(self, df: pd.DataFrame) -> dict:
        """Returns a JSON-compatible schema description"""
        schema = {}
        for col in df.columns:
            dtype = str(df[col].dtype)
            if 'datetime' in dtype:
                schema[col] = 'TIMESTAMP'
            elif 'float' in dtype or 'int' in dtype:
                schema[col] = 'NUMERIC'
            else:
                schema[col] = 'TEXT'
        return schema

    def export_csv(self, df: pd.DataFrame, session_id: str) -> str:
        """Saves transform to specific folder"""
        output_dir = os.path.join("uploaded_data", session_id)
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, "cleaned_data.csv")
        df.to_csv(path, index=False)
        return path


class DataLoader:
    """
    Handles Database interactions using SQLAlchemy Core (Dynamic Tables)
    """

    def __init__(self, db_session):
        self.db = db_session
        self.metadata = MetaData()

    def get_sqlalchemy_type(self, series: pd.Series):
        """Map pandas types to SQLAlchemy types"""
        if pd.api.types.is_integer_dtype(series):
            return Integer
        elif pd.api.types.is_float_dtype(series):
            return Float
        elif pd.api.types.is_datetime64_any_dtype(series):
            return DateTime
        else:
            return String

    def create_table_from_df(self, df: pd.DataFrame, table_name: str):
        """
        Dynamically creates a table based on DataFrame dtypes.
        Drops table if it exists to ensure schema match.
        """
        # Drop if exists
        self.metadata.reflect(bind=engine)
        if table_name in self.metadata.tables:
            base_table = self.metadata.tables[table_name]
            base_table.drop(engine)

        # Define columns dynamically
        cols = [Column('id', Integer, primary_key=True, autoincrement=True)]

        for col_name in df.columns:
            dtype = self.get_sqlalchemy_type(df[col_name])
            cols.append(Column(col_name, dtype))

        # Create Table
        table = Table(table_name, self.metadata, *cols)
        self.metadata.create_all(engine)
        return table

    def insert_dataframe(self, df: pd.DataFrame, table_name: str, session_id: str, file_name: str, csv_path: str):
        """
        Bulk insert and Audit log.
        """
        # 1. Ensure Table Exists
        table = self.create_table_from_df(df, table_name)

        # 2. Convert DF to dict for insertion
        # Handle NaN/None for SQL
        data = df.where(pd.notnull(df), None).to_dict(orient='records')

        try:
            # 3. Bulk Insert
            with engine.connect() as conn:
                conn.execute(table.insert(), data)
                conn.commit()

            # 4. Audit Log
            audit = UploadAudit(
                session_id=session_id,
                filename=file_name,
                csv_path=csv_path,
                rows_inserted=len(data),
                created_table=table_name
            )
            self.db.add(audit)
            self.db.commit()

            return True, f"Inserted {len(data)} rows into '{table_name}'."
        except Exception as e:
            self.db.rollback()
            return False, str(e)