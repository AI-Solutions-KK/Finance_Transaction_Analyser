# Path: backend/main.py

import os
import uuid
from tools.tools import DataTransformer
from tools.load_all_tables import load_all_tables


class BackendController:
    def __init__(self):
        self.transformer = DataTransformer()

    def process_file(self, uploaded_file, file_ext):
        """
        1. Save uploaded file
        2. Parse & clean
        3. Export CSV
        4. Return dataframe + metadata
        """
        session_id = str(uuid.uuid4())

        # Create session folder
        temp_dir = os.path.join("uploaded_data", session_id)
        os.makedirs(temp_dir, exist_ok=True)

        temp_path = os.path.join(temp_dir, f"raw{file_ext}")

        # Save uploaded file
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        # Parse & clean
        df = self.transformer.parse_file(temp_path, file_ext)

        # Export cleaned CSV
        csv_path = self.transformer.export_csv(df, session_id)

        # Schema manifest (for UI display)
        manifest = self.transformer.generate_schema_manifest(df)

        return {
            "df": df,
            "session_id": session_id,
            "csv_path": csv_path,
            "manifest": manifest
        }

    def load_to_database(self, df, table_name, session_id, filename, csv_path):
        """
        FINAL DB LOAD:
        - Ignores dynamic table_name
        - Loads into FACT & DIM tables
        """
        try:
            load_all_tables(
                csv_path=csv_path,
                session_id=session_id
            )
            return True, "Data loaded into analytics tables successfully"
        except Exception as e:
            return False, str(e)


# Singleton controller
controller = BackendController()
