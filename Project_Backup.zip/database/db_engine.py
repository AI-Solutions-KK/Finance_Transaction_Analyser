# Path: database/db_engine.py
# FINAL analytics schema (no IDs, BI-friendly)

import os
from datetime import datetime
from sqlalchemy import (
    create_engine, Column, Integer, String,
    Numeric, Date, DateTime
)
from sqlalchemy.orm import declarative_base, sessionmaker

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "transaction_analyser.db")

engine = create_engine(
    f"sqlite:///{DB_PATH}",
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class FactTransaction(Base):
    __tablename__ = "fact_transactions"

    txn_id = Column(Integer, primary_key=True)

    session_id = Column(String, index=True)
    txn_date = Column(Date)

    transaction_ref_id = Column(String)        # extracted number
    transaction_code = Column(String)           # UPI, CWDR, SBInt
    transaction_method = Column(String)         # UPI, ATM, BANK
    transaction_category = Column(String)       # EMI, FOOD, SHOPPING
    transaction_nature = Column(String)         # INCOME / EXPENSE / TRANSFER

    counterparty_name = Column(String)
    counterparty_bank_code = Column(String)     # BOI, HDFC, SBI

    debit = Column(Numeric)
    credit = Column(Numeric)
    amount = Column(Numeric)
    balance = Column(Numeric)

    remarks = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)
